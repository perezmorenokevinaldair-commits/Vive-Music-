# Mi Música — Android

Reproductor de música local con interfaz Liquid Glass inspirada en las pantallas de referencia.

## Incluye

- Música local del teléfono mediante MediaStore.
- Importación de archivos de audio con selector del sistema.
- Reproducir / pausar / anterior / siguiente.
- Barra de progreso y volumen.
- Aleatorio y repetición.
- Favoritos guardados localmente.
- Conteo de reproducciones.
- Minutos escuchados.
- Sección Escuchar ahora / Recents.
- Álbumes y biblioteca.
- Mini-reproductor.
- Reproducción en segundo plano y controles del sistema mediante Media3 MediaSessionService.
- Diseño oscuro con superficies translúcidas tipo Liquid Glass.

## Abrir en Android Studio

1. Descomprime el ZIP.
2. Abre la carpeta `MiMusica` en Android Studio.
3. Espera a que Gradle sincronice.
4. Conecta un teléfono Android o usa un emulador.
5. Pulsa Run.

El proyecto usa Kotlin + Jetpack Compose + Media3.

## Nota

Este repositorio contiene el código fuente del proyecto Android. No incluye canciones ni portadas con copyright. Las canciones se toman del dispositivo del usuario o se importan mediante el selector de archivos.
