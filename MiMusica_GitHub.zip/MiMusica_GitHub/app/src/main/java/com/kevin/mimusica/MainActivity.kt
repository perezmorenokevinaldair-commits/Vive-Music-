package com.kevin.mimusica

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.delay
import java.util.Locale

private val Black = Color(0xFF000000)
private val Glass = Color(0x18FFFFFF)
private val GlassStrong = Color(0x28FFFFFF)
private val Muted = Color(0xFF9B9B9B)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Black,
                    surface = Color(0xFF0B0B0B),
                    primary = Color.White
                )
            ) {
                MusicApp()
            }
        }
    }
}

@Composable
private fun MusicApp() {
    val context = LocalContext.current
    var songs by remember { mutableStateOf(emptyList<Music>()) }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var selectedTab by remember { mutableStateOf(0) }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }

    fun loadSongs() {
        songs = queryMusic(context)
    }

    val permission = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_AUDIO
    else
        Manifest.permission.READ_EXTERNAL_STORAGE

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) loadSongs()
    }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) { }
            }
            songs = songs + uris.mapIndexed { i, uri ->
                Music("import-$i-${uri}", uri.lastPathSegment ?: "Canción", "Archivo local", "Importadas", uri)
            }
        }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
            loadSongs()
        } else {
            permissionLauncher.launch(permission)
        }

        val token = SessionToken(context, android.content.ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            controller = future.get()
        }, MoreExecutors.directExecutor())
    }

    DisposableEffect(Unit) {
        onDispose {
            controller?.release()
        }
    }

    val visibleSongs = songs.filter {
        search.isBlank() ||
            it.title.contains(search, true) ||
            it.artist.contains(search, true) ||
            it.album.contains(search, true)
    }

    Box(Modifier.fillMaxSize().background(Black)) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 18.dp)
        ) {
            Spacer(Modifier.height(14.dp))
            TopBar(onSearch = { search = if (search.isBlank()) " " else "" })

            if (search.isNotBlank()) {
                OutlinedTextField(
                    value = search.trimStart(),
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    placeholder = { Text("Buscar canciones, artistas o álbumes") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color.White,
                        unfocusedBorderColor = Color.DarkGray
                    )
                )
            }

            when (selectedTab) {
                0 -> HomeScreen(
                    songs = visibleSongs,
                    controller = controller,
                    favorites = favorites,
                    onPlay = { playSongs(controller, songs, it, shuffle) },
                    onFavorite = { id ->
                        favorites = if (id in favorites) favorites - id else favorites + id
                    }
                )
                1 -> ExploreScreen(songs, controller, shuffle)
                else -> LibraryScreen(
                    songs = visibleSongs,
                    favorites = favorites,
                    onPick = { picker.launch(arrayOf("audio/*")) },
                    onPlay = { playSongs(controller, songs, it, shuffle) },
                    onFavorite = { id ->
                        favorites = if (id in favorites) favorites - id else favorites + id
                    }
                )
            }

            Spacer(Modifier.height(8.dp))

            MiniPlayer(controller)

            NavigationBar(
                containerColor = Color(0xFF111111),
                modifier = Modifier.navigationBarsPadding().clip(RoundedCornerShape(30.dp))
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, null) },
                    label = { Text("Inicio") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Search, null) },
                    label = { Text("Explorar") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.LibraryMusic, null) },
                    label = { Text("Biblioteca") }
                )
            }
        }
    }
}

@Composable
private fun TopBar(onSearch: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = CircleShape,
            color = Glass,
            modifier = Modifier.size(50.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.QueueMusic, null)
            }
        }
        Surface(
            shape = RoundedCornerShape(30.dp),
            color = Glass,
            modifier = Modifier.height(50.dp)
        ) {
            Row(
                Modifier.padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("♪", fontSize = 23.sp)
                Spacer(Modifier.width(10.dp))
                Text("Mi Música", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun HomeScreen(
    songs: List<Music>,
    controller: MediaController?,
    favorites: Set<String>,
    onPlay: (Int) -> Unit,
    onFavorite: (String) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.weight(1f)
    ) {
        item {
            Text(
                "Escuchar ahora",
                fontSize = 43.sp,
                lineHeight = 45.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(Modifier.height(25.dp))
            Text("Recents", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        }

        if (songs.isEmpty()) {
            item {
                GlassCard {
                    Text(
                        "No encontré música local todavía.\nUsa Biblioteca para importar archivos de audio.",
                        color = Muted
                    )
                }
            }
        } else {
            itemsIndexed(songs.take(10)) { index, song ->
                SongRow(
                    song = song,
                    favorite = song.id in favorites,
                    onClick = { onPlay(index) },
                    onFavorite = { onFavorite(song.id) }
                )
            }
        }

        item {
            Spacer(Modifier.height(18.dp))
            Text("Álbumes y singles", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(10.dp))
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                itemsIndexed(songs.distinctBy { it.album }.take(10)) { _, song ->
                    AlbumCard(song.album)
                }
            }
        }
    }
}

@Composable
private fun ExploreScreen(
    songs: List<Music>,
    controller: MediaController?,
    shuffle: Boolean
) {
    Column(Modifier.weight(1f)) {
        Text("Explorar", fontSize = 43.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(20.dp))
        GlassCard {
            Text("Tu música local", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "${songs.size} canciones disponibles en este dispositivo.",
                color = Muted
            )
        }
        GlassCard {
            Text("Reproducción", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                if (shuffle) "Aleatorio activado" else "Orden normal",
                color = Muted
            )
        }
    }
}

@Composable
private fun LibraryScreen(
    songs: List<Music>,
    favorites: Set<String>,
    onPick: () -> Unit,
    onPlay: (Int) -> Unit,
    onFavorite: (String) -> Unit
) {
    Column(Modifier.weight(1f)) {
        Text("Biblioteca", fontSize = 43.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = onPick,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color.Black
            )
        ) {
            Text("＋ Agregar música del dispositivo", fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(15.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(songs) { index, song ->
                SongRow(
                    song = song,
                    favorite = song.id in favorites,
                    onClick = { onPlay(index) },
                    onFavorite = { onFavorite(song.id) }
                )
            }
        }
    }
}

@Composable
private fun SongRow(
    song: Music,
    favorite: Boolean,
    onClick: () -> Unit,
    onFavorite: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(17.dp))
            .clickable(onClick = onClick)
            .padding(5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(62.dp).clip(RoundedCornerShape(13.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF555555), Color(0xFF171717)))),
            contentAlignment = Alignment.Center
        ) {
            Text("♪", fontSize = 25.sp)
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (song.artist.isBlank()) "Artista desconocido" else song.artist,
                color = Muted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = onFavorite) {
            Icon(
                if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                null
            )
        }
        Icon(Icons.Default.MoreVert, null, tint = Muted)
    }
}

@Composable
private fun AlbumCard(album: String) {
    Column(Modifier.width(185.dp)) {
        Box(
            Modifier.size(185.dp).clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF6A6A6A), Color(0xFF181818)))),
            contentAlignment = Alignment.Center
        ) {
            Text(
                album.ifBlank { "Álbum" },
                fontWeight = FontWeight.Black,
                fontSize = 22.sp,
                modifier = Modifier.padding(12.dp)
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(album.ifBlank { "Single" }, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text("Música local", color = Muted, maxLines = 1)
    }
}

@Composable
private fun MiniPlayer(controller: MediaController?) {
    var title by remember { mutableStateOf("Ninguna canción") }
    var artist by remember { mutableStateOf("Selecciona una canción") }
    var playing by remember { mutableStateOf(false) }

    LaunchedEffect(controller) {
        while (true) {
            controller?.let {
                title = it.mediaMetadata.title?.toString() ?: "Ninguna canción"
                artist = it.mediaMetadata.artist?.toString() ?: "Música local"
                playing = it.isPlaying
            }
            delay(250)
        }
    }

    Surface(
        color = Color(0xE6202020),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
    ) {
        Row(
            Modifier.padding(9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF666666), Color(0xFF222222)))),
                contentAlignment = Alignment.Center
            ) { Text("♪", fontSize = 22.sp) }

            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(artist, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }

            IconButton(onClick = {
                controller?.let { if (it.isPlaying) it.pause() else it.play() }
            }) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
            }
            IconButton(onClick = { controller?.seekToNextMediaItem() }) {
                Icon(Icons.Default.SkipNext, null)
            }
        }
    }
}

@Composable
private fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        color = Glass,
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(17.dp), content = content)
    }
}

private fun playSongs(
    controller: MediaController?,
    songs: List<Music>,
    index: Int,
    shuffle: Boolean
) {
    if (controller == null || songs.isEmpty() || index !in songs.indices) return

    val items = songs.map { song ->
        MediaItem.Builder()
            .setMediaId(song.id)
            .setUri(song.uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(song.title)
                    .setArtist(song.artist)
                    .setAlbumTitle(song.album)
                    .build()
            )
            .build()
    }

    controller.setMediaItems(items, index, 0L)
    controller.shuffleModeEnabled = shuffle
    controller.prepare()
    controller.play()
}

private fun queryMusic(context: android.content.Context): List<Music> {
    val result = mutableListOf<Music>()
    val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM
    )
    val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"

    context.contentResolver.query(
        collection,
        projection,
        selection,
        null,
        "${MediaStore.Audio.Media.DATE_ADDED} DESC"
    )?.use { cursor ->
        val id = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val title = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artist = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val album = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)

        while (cursor.moveToNext()) {
            val mediaId = cursor.getLong(id)
            result += Music(
                id = mediaId.toString(),
                title = cursor.getString(title) ?: "Sin título",
                artist = cursor.getString(artist) ?: "Artista desconocido",
                album = cursor.getString(album) ?: "Álbum",
                uri = ContentUris.withAppendedId(collection, mediaId)
            )
        }
    }
    return result
}
