package com.kevin.mimusica

import android.net.Uri

data class Music(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val uri: Uri
)
